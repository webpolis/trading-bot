class Whale:
    def __init__(self):
        self.address = None
        self.balance = None
        self.mkt_share = None
        self.movements = {}
